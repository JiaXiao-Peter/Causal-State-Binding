# AI Open editable manuscript — integrated narrative, 2 October 2026

Entry points: `main_ai_open_author.tex` and `supplementary_information_ai_open.tex`. The original submitted title and elsarticle author-year template are retained, with nine main and fourteen supplementary figures. The linked SI reading guide and bookmarks identify study methods, additional analyses and source experiments.

The article is organized by the state--action question: controlled responses, agent-written state, content and identifiers, action direction, and localization reliability. The methods specify development, exploratory and independent-evaluation roles. The overview explains each comparison before its notation; generation-budget controls accompany the controlled results, and repair is discussed with localization. Methods collect exact model settings, feature construction, preprocessing and inference. Discussion connects the findings to memory utilization, causal interventions and uncertainty estimation with primary-source support. Scientific observations, numerical results and equations are unchanged. Figure colors distinguish methods, components, outcomes and models; plotted values, scales, panel geometry and text size are unchanged.

The source ZIP contains every active TeX dependency, bibliography, local class/style files, all 23 vector figures and their plotted CSVs, including the detailed task and paired-prediction displays. `figures/current/source_data/README.md` identifies the additional data tables. Three supplementary CSV sidecars retain full table values or exact historical source cells. `reproducibility_details.tex` specifies execution inference, checkpoint encoding and repository retrieval. `prediction_feature_definitions.tex` and `final_prediction_methods.tex` specify ordered diagnostic responses and frozen predictors.

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error main_ai_open_author.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error supplementary_information_ai_open.tex
```

The release uses local MiKTeX pdfTeX 4.26 / MiKTeX 26.2 and latexmk 4.88. The two PDFs are independently rebuilt from the extracted ZIP and compared by page text and rendered pixels. Vector figures use full-text-width uniform scaling. Figures start at paragraph boundaries; detailed legends remain with the figure or immediately after it, without reducing the artwork to fit.

The public [research package](https://github.com/JiaXiao-Peter/Causal-State-Binding/raw/refs/heads/main/research/CSB_research_materials_20261001.zip) contains saved analysis inputs, frozen predictions, trained predictors, protocols and offline reproduction instructions. It is distinct from this typesetting ZIP. The identical local copy is `reviewer_research_package.zip`; it may also accompany the submission. No credentials or new model calls are required for the packaged reproduction commands.

In the complete workspace, `python -B maintenance/current.py verify` checks delivery; `pdf` builds and renders; `figures` checks figure inputs; `package` verifies the checked delivery and refreshes its manifest. Independent source-ZIP builds are checked during release registration and retained in the verification record. Do not replay historical editing or collection scripts over the active manuscript.
