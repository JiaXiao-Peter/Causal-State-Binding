# Plotted scientific data

Each vector figure has a same-name CSV. Where a figure combines existing summaries with newly displayed detail, its `_detail.csv` supplies the additional observations and descriptive aggregates. The `panel` column follows the lettered panels in the current artwork. Blank fields indicate that a column belongs to a different panel type in the same long-form file.

- `figure2_execution_detail.csv`: all paired task means for the eight model/component panels; the marginal histograms use these same task counts.
- `figure3_specificity_detail.csv`: original/replaced action-target scores and the discrete distribution of task differences for history compensation.
- `figure_content_confirmation_detail.csv`: the full task-by-condition matrices and within-mechanism distributions. Saved inferential intervals remain in the base CSV.
- `figure_prediction_independent_detail.csv`: the 10,000 saved paired AUC draws and repository/model summaries, including outcome-class support. Bootstrap draws are repeated resamples, not independent new issues. Repository/model AUC is undefined when only one outcome class is present.
- `figure_calibration_independent_detail.csv`: paired frozen probabilities and actual outcomes. Fixed-bin calibration and support are retained in the base CSV.

All new displays are deterministic summaries of existing records. No model was refitted and no bootstrap sample was added for this revision. The figure captions identify the applicable analysis unit, denominator and interval. The original effect estimates, reference categories, failed cases and registered comparisons remain unchanged. The accompanying reviewer research package includes the underlying observations and the single current plotting command.
